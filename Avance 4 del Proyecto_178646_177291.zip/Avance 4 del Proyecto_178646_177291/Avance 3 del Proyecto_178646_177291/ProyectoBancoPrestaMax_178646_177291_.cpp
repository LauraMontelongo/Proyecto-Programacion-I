//16 de Mayo de 2022
//Uriel Martinez Monreal - 178646
//Laura Ivon Montelongo Martinez - 177291


#include <stdio.h>
#include <conio.h>	 //Librerias para las funciones del programa
#include <stdlib.h>
#include <iostream>
#include <windows.h>
#include <string.h>
#include <ctype.h>
#include <locale.h>
#include <time.h>
#include <iostream>
#include <ctime>
#include <vector>
#define claveadmi 177291
	//Estructura que contiene la informaci�n del cliente
	struct datos{
		
	  char name[30],clave[10];
	  float saldo;
	  int cliente;
	  
	};
	
	
//Aqu� encontramos los prototipos de nuestras funciones
float retirar (float &, float &,float &,FILE *archivo,FILE *archivo2);//Funcion para llevar acabo la acci�n de retirar dinero
float depositar (float &, float &,float &,FILE *archivo,FILE *archivo2);//Funcion para llevar acabo deposito en la cuenta
void key (char clave[10]);//Funcion que contiene la validacion de la clave de ingreso
void tabla (void);//Funcion que contiene la estructura de la tabla de datos mostrado en consultas


//Declaraci�n para poder usar gotoxy
void gotoxy(int x,int y){
HANDLE hcon;
hcon = GetStdHandle(STD_OUTPUT_HANDLE);
COORD dwPos;
dwPos.X = x;
dwPos.Y= y;
SetConsoleCursorPosition(hcon,dwPos);
}
int main(){
	
	//Declaraci�n para poner color en el texto
	HANDLE hd = GetStdHandle(STD_OUTPUT_HANDLE);
	HANDLE hConsole;
	hConsole=GetStdHandle(STD_OUTPUT_HANDLE);
	
	//Declaraci�n de variables
	char clave[10], nombre[30], opcion4;
	int opcion, opcion2, opcion3,x,y,numero=1;
	float newsaldo=3000,saldo,dep, retiro,depfinal=0,retirfinal=0;
	
	//Declaraciones de punteros que llevan a nuestra esturctura "datos"
	struct datos *ptr_alt;
	struct datos dar;
	ptr_alt=&dar;

	//Declaraciones de archivos
	FILE *archivo;
	FILE *archivo2;
	/*struct tm *ptr_tim;
	struct tm fecha;
	ptr_tim=&fecha;*/

	do{
		
		//Imprimimos el encabezado de nuestro proyecto
		SetConsoleTextAttribute(hConsole,15);
		printf("\tProyecto desarrollado por: \n\n");
		printf("Uriel Martinez Monreal \t Laura Ivon Montelongo Martinez\n\n");
		
		SetConsoleTextAttribute(hConsole,6);				
		printf("Bienvenido a Banco PrestaMax 'Hogar del dinero'\n\n");
		SetConsoleTextAttribute(hConsole,15);
		
		system("pause");//El programa se bloquea hasta que el usuario escriba algo.
		system("cls");//Limpia la pantalla
				
				
		//Pediamos el nombre del usuario
		/*printf("Ingresa tu nombre: \n");
		scanf("%[^\n]", nombre);
		fflush(stdin);*///Limpia para limpiar el buffer del teclado
			
			
		//Le mostramos las opciones del programa al cliente
		printf("\nA que sector quieres acceder?\n");
		printf("1.- Administracion del banco\n");		
		printf("2.- Cliente del banco\n");
		printf("3.- Salir \n");
		
		scanf("%d", &opcion);
		fflush(stdin);//Limpia para limpiar el buffer del teclado
		
		switch(opcion){
			
			case 1:	
				int administ;
				do{
					
					printf("\nIngresa la clave de acceso: \n");
					scanf("%d",&administ);
				}while(administ!=claveadmi);

			do{
				if(administ==claveadmi){
				
					//Opciones para el administrador
					printf("A que area quieres acceder?\n");
					printf("1.- Alta clientes\n");
					printf("2.- Modificacion de informacion\n"); 		
					printf("3.- Consulta de clientes\n");
					printf("4.- Salir\n");
					
					scanf("%d", &opcion2);
					fflush(stdin);//Limpia para limpiar el buffer del teclado
					
					switch(opcion2){
						
						case 1:	
						
							/*Pedimos al usuario sus datos*/
							printf("Nombre: ");
							scanf("%s",ptr_alt->name);//Guardamos los datos en el puntero (ptr_alt) que apunta a nuestra estructura
							
							printf("Clave: ");
							scanf("%s",ptr_alt->clave);//Guardamos los datos en el puntero (ptr_alt) que apunta a nuestra estructura
							
							printf("Numero de cliente: ");
							scanf("%d",&ptr_alt->cliente);//Guardamos los datos en el puntero (ptr_alt) que apunta a nuestra estructura
							
							printf("Saldo: ");
							scanf("%f",&ptr_alt->saldo);//Guardamos los datos en el puntero (ptr_alt) que apunta a nuestra estructura
							
							/*Abrimos nuestro archvio (a+ .. abre/crea un archivo para lectura y escritura al final del contenido*/
							if(!(archivo = fopen("altas.txt", "a+"))){
								printf("El archivo prueba no existe");
								exit(1);
								/* informa al sistema operativo que el programa no se ejecut� con �xito, o se anul� entre la 
								ejecuci�n debido a alg�n error u otro.*/
							}
							
							
							//Imprimimos los datos en nuestro fichero/archivo
							fprintf(archivo, "%s\t",ptr_alt->name);
							fprintf(archivo, "%s\t",ptr_alt->clave);
							fprintf(archivo, "%d\t",ptr_alt->cliente);
							fprintf(archivo, "%0.2f\n",ptr_alt->saldo);
	
							//Cerramos nuestro archivo una vez que se acabo de usar
							fclose(archivo);
							//alta clientes
							
						break;
						
						case 2:	
							//leer_archivo();	
							
							int cliente;
							float nuevosaldo;
							if(!(archivo=fopen("altas.txt", "r"))){//Abrimos nuestro archivo para lectura (Archivo original)
								printf("El archivo prueba no existe");
								exit(1);
							}
							
							if(!(archivo2=fopen("altasnew.txt", "a+"))){//Creamos y abrimos un segundo archivo 
								printf("El archivo prueba no existe");
								exit(1);
							}
							
							//Preguntamos a que cliente se quiere cambiar los datos
							printf("A que numero de cliente pertenecen los datos que quieres cambiar: ");						
							scanf("%d",&cliente);
							
							
							//Usamos feof para comprobar el indicador de fin de archivo en el flujo de archivo dado
							while(!feof(archivo)){
								
								//Escaneamos/leemos los datos del archivo
								fscanf(archivo,"%[^\t]\t", ptr_alt->name);
								fscanf(archivo,"%s\t", ptr_alt->clave);
								fscanf(archivo,"%d\t", &ptr_alt->cliente);
								fscanf(archivo,"%f\n", &ptr_alt->saldo);
								
								
								//Si el cliente al que queremos acceder es igual al cliente que tenemos en nuestra estructura entonces:
								if(ptr_alt->cliente == cliente){
								
									//Le imprimimos al usuario los datos
									printf("%s\t", ptr_alt->name);
									printf("%s\t", ptr_alt->clave);
									printf("%d\t", ptr_alt->cliente);
									printf("%0.2f\t", ptr_alt->saldo);
								
									do{
								
										//Cambiamos el dato de saldo y pedimos uno nuevo
										printf("Nuevo saldo del cliente: ");
										scanf("%f", &nuevosaldo);
											
										//Si el nuevo valor es menor a 0:
										if (nuevosaldo<0) printf("Valor no valido\n");						
							
									}while(nuevosaldo<0);
									
									//El saldo de nuestra estructura toma el valor del nuevo saldo introducido
									ptr_alt->saldo = nuevosaldo;
									fflush(stdin);
									
									//Pedimos el nuevo nombre del cliente
									printf("Nuevo nombre del cliente: ");
									scanf("%[^\n]", ptr_alt->name);//Lo guardamos en ptr_alt -> va a nuestra estructura
	
							
								}
								
								//Imprimimos todo en nuestro archivo 2
								fprintf(archivo2,"%s\t", ptr_alt->name);
								fprintf(archivo2,"%s\t", ptr_alt->clave);
								fprintf(archivo2,"%d\t", ptr_alt->cliente);
								fprintf(archivo2,"%0.2f\n", ptr_alt->saldo);
							}
	
							//Cerramos nuestro archivos a traves de fclose
							fclose(archivo2);
							fclose(archivo);
							remove("altas.txt");//Removemos nuestro documento original
							rename("altasnew.txt", "altas.txt");//El archivo copia lo renombramos como el archivo original
							/*Es decir remplazamos lo que hay en el archivo copia y lo pasamos a nuestro archivo principal*/
								
							//leer_archivo();
						break;
						
						case 3:
							
							//Abrimos nuestro archivo para lectura
							archivo = fopen("altas.txt", "r");
							
							if(archivo == NULL){//Coprobamos que nuestro archivo existe
								printf("\nFichero no existe! \nPor favor creelo");
								return(0);
							}
							
							//Usamos feof para comprobar el indicador de fin de archivo en el flujo de archivo dado
							 while(!feof(archivo)){
							 	
							 	//Escanemaos los datos de nuestro archivo
								fscanf(archivo,"%s\t", ptr_alt->name);
								fscanf(archivo,"%s\t", ptr_alt->clave);
								fscanf(archivo,"%d\t", &ptr_alt->cliente);
								fscanf(archivo,"%f\n", &ptr_alt->saldo);
						
								//Imprimos estos datos para el usuario una vez escaneados/leidos
								printf("%s\t", ptr_alt->name);
								printf("%s\t", ptr_alt->clave);
								printf("%d\t", ptr_alt->cliente);
								printf("%0.2f\n", ptr_alt->saldo);
								numero++;
							}
							
							//Cerramos nuestro archivo a traves e fclose
							fclose(archivo);
							printf("\n\n");
							
						break;
						
						case 4:
							
							printf("Saliendo de las opciones\n");
						
						break;
							
						default:
						
						printf("Opcion invalida\n");
						
						break;			
					}
				}
			}while(opcion2!=4);  //Regresa a elegir opciones para el banquero
			system("cls");
			break;
				
			case 2:	
					
		do{
			
				key(clave);
				
				
				//Despues de que la clave sea valida se muestran las opciones para el usuario
		
								
				printf("A que area quieres acceder\n");
				printf("1.- Consulta de movimientos\n");	
				printf("2.- Deposito\n");
				printf("3.- Retiro\n");
				printf("4.- Salida\n");
				scanf("%d", &opcion3); //Leemos la accion que quiere realizar el usuario
				fflush(stdin);	//Limpia para limpiar el buffer del teclado
							
				switch(opcion3){
					
					
				
					case 1:	
					
					do{
					
						//consulta de movimientos -> Opciones
						
						printf("\nQue tipo de consulta necesitas? ");
						printf("\na) Consulta por semana");
						printf("\nb) Consulta por mes");
						printf("\nc) Consulta del presente a�o");
						printf("\nd) Consulta de una fecha especifica\n");
						printf("\ne) Salir\n");
						scanf("%c", &opcion4);//Leemos la opcion que quiere llevar acabo el usuario
						fflush(stdin);	//Limpia para limpiar el buffer del teclado
							
					switch(opcion4){
						
						case 'a':
							
							
							int dia;
							int cliente;
			
						/*	if(!(archivo=fopen("altas.txt", "r"))){//Abrimos nuestro archivo original en modo lectura
									printf("El archivo prueba no existe");
									exit(1);
							}
							printf("Cual es tu numero de cliente es: ");						
							scanf("%d",&cliente);
									
							while(!feof(archivo)){
							
								//Escaneamos los datos dentro del archivo
								fscanf(archivo,"%[^\t]\t", ptr_alt->name);
								fscanf(archivo,"%s\t", ptr_alt->clave);
								fscanf(archivo,"%d\t", &ptr_alt->cliente);
								fscanf(archivo,"%f\n", &ptr_alt->saldo);
								
								if(ptr_alt->cliente == cliente){
								gotoxy(70,4);
								printf("%0.2f\n", ptr_alt->saldo);
								}
							}*/
										
										
							fclose(archivo);
						
						//El usuario introducira de manera numerica el dia de la semana
						    printf( "\n   Introduzca dia de la semana: ");
						    scanf( "%d", &dia );//Leemos su respuesta

    						if ( dia >= 1 && dia <= 7 )//Si el dia de la semana va del 1 al 7 entonces:
						    /* S�lo si el d�a es v�lido,
						       se ejecuta la instrucci�n switch */
						
						    /* Inicio del anidamiento */
					        switch ( dia )
					        {
					        
					            case 1 : tabla(); //Llamado de nuestra funcion
					            
					            
					            		/*Utilizamos gotoxy para imprimir los datos correspondientes 
										en la estructura de nuestra tabla*/
					            		gotoxy(4,4);
				  						printf(" Lunes");
				  						
				  						gotoxy(22,4);
				  						 printf("3000");
				  						
				  						 gotoxy(53,4);
				  						 printf("%0.2f",retirfinal);
				  						 
										 gotoxy(37,4);
				  						 printf("%0.2f", depfinal);
										
									     gotoxy(70,4);
				  						 printf("%0.2f", ptr_alt->saldo);
				  						 
				  						gotoxy(35,10);
			  							 printf("");
			  							getch();//Espera hasta que se pulsa una tecla y entonces devuelve su valor.
			  							
					                     break;
					                     
					            
					            case 2 : tabla(); //Lamado a nuestra funcion
					            /*Utilizamos gotoxy para imprimir los datos correspondientes 
								en la estructura de nuestra tabla*/
					            		gotoxy(4,4);
				  						printf(" Martes");
				  						
				  						gotoxy(22,4);
				  						 printf("3000");
				  						
				  						 gotoxy(53,4);
				  						 printf("%0.2f",retirfinal);
				  						 
										 gotoxy(37,4);
				  						 printf("%0.2f", depfinal);
				  						 
									     gotoxy(70,4);
				  						 printf("%0.2f", newsaldo);
				  						 gotoxy(35,10);
			  							 printf("");
			  							getch(); //Espera hasta que se pulsa una tecla y entonces devuelve su valor.
					                    break;
					                     
					            case 3 : tabla(); //Lamado a nuestra funcion
					            
					            /*Utilizamos gotoxy para imprimir los datos correspondientes 
								en la estructura de nuestra tabla*/
					            	     gotoxy(4,4);
					  					 printf("Miercoles", 130);
					  					 
					  					 gotoxy(22,4);
				  						 printf("3000");
				  						
				  						 gotoxy(53,4);
				  						 printf("%0.2f",retirfinal);
				  						 
										 gotoxy(37,4);
				  						 printf("%0.2f", depfinal);
				  						 
									     gotoxy(70,4);
				  						 printf("%0.2f", newsaldo);
				  						 gotoxy(35,10);
			  							 printf("");
			  							 getch(); //Espera hasta que se pulsa una tecla y entonces devuelve su valor.
					                     break;
					                     
					            case 4 : tabla(); //Lamado a nuestra funcion
					            
					            /*Utilizamos gotoxy para imprimir los datos correspondientes 
								en la estructura de nuestra tabla*/
										 gotoxy(4,4);
										 printf( "Jueves" );
										 
										 gotoxy(22,4);
				  						 printf("3000");
				  						
				  						 gotoxy(53,4);
				  						 printf("%0.2f",retirfinal);
				  						 
										 gotoxy(37,4);
				  						 printf("%0.2f", depfinal);
				  						 
									     gotoxy(70,4);
				  						 printf("%0.2f", newsaldo);
				  						 gotoxy(35,10);
			  							 printf("");
			  							 getch(); //Espera hasta que se pulsa una tecla y entonces devuelve su valor.
					                     break;
					                     
					            case 5 : tabla(); //Lamado a nuestra funcion
					            
					            /*Utilizamos gotoxy para imprimir los datos correspondientes 
								en la estructura de nuestra tabla*/
										 gotoxy(4,4);
										 printf( "Viernes" );
										 
										 gotoxy(22,4);
				  						 printf("3000");
				  						
				  						 gotoxy(53,4);
				  						 printf("%0.2f",retirfinal);
				  						 
										 gotoxy(37,4);
				  						 printf("%0.2f", depfinal);
				  						 
									     gotoxy(70,4);
				  						 printf("%0.2f", newsaldo);
										 gotoxy(35,10);
			  							 printf("");
										 getch(); //Espera hasta que se pulsa una tecla y entonces devuelve su valor.
					                     break;
					                     
					            case 6 : tabla(); //Lamado a nuestra funcion
					            
					            /*Utilizamos gotoxy para imprimir los datos correspondientes 
								en la estructura de nuestra tabla*/
										 gotoxy(4,4);
										 printf( "Sabado", 160 );
										 
										 gotoxy(22,4);
				  						 printf("3000");
				  						
				  						 gotoxy(53,4);
				  						 printf("%0.2f",retirfinal);
				  						 
										 gotoxy(37,4);
				  						 printf("%0.2f", depfinal);
				  						 
									     gotoxy(70,4);
				  						 printf("%0.2f", newsaldo);
				  						 gotoxy(35,10);
			  							 printf("");
			  							 getch(); //Espera hasta que se pulsa una tecla y entonces devuelve su valor.
					                     break;
					                     
					            case 7 : tabla(); //Lamado a nuestra funcion
					            
					            /*Utilizamos gotoxy para imprimir los datos correspondientes 
								en la estructura de nuestra tabla*/
								         gotoxy(4,4);
										 printf( "Domingo" );
										 
										gotoxy(22,4);
				  						 printf("3000");
				  						
				  						 gotoxy(53,4);
				  						 printf("%0.2f",retirfinal);
				  						 
										 gotoxy(37,4);
				  						 printf("%0.2f", depfinal);
				  						 
									     gotoxy(70,4);
				  						 printf("%0.2f", newsaldo);
				  						 gotoxy(35,10);
			  							 printf("");
			  							 getch(); //Espera hasta que se pulsa una tecla y entonces devuelve su valor.
										 break;
										 
								//Si la cantinada introducida no se encuentra entre 1 a 7 entonces:
								default: printf( "\n   ERROR: Dia incorrecto.");
										break;
					        }

						break;
						
						case 'b':
						
					   	
							tabla();//Llamado a nuestra funcion
							
							//Declarado para generar el mes del sistema
							time_t t;
						    struct tm *tm;
						    char fechayhora[100];
						
						    t=time(NULL);
						    tm=localtime(&t);
					   	 	strftime(fechayhora, 100, "%m/%Y", tm);
						    SetConsoleTextAttribute(hd,15);
						    /*Utilizamos gotoxy para imprimir los datos correspondientes 
								en la estructura de nuestra tabla*/
						  	gotoxy(6,4);
						    printf("%s\n", fechayhora); 
							gotoxy(22,4);
				  			printf("3000");
				  						
				  			gotoxy(53,4);
				  			printf("%0.2f",retirfinal);
				  						 
							gotoxy(37,4);
				  		    printf("%0.2f", depfinal);
				  						 
							gotoxy(70,4);
							printf("%0.2f", newsaldo);
							gotoxy(35,10);
			  				printf("");
  							getch();
								
							
						break;
						
						case 'c':
						
							//a�o
							  tabla();
							//Declarado para generar el a�o del sistema
							  t=time(NULL);
							  tm=localtime(&t);
							  gotoxy(3,4);
							  printf ("Hoy es: %d\n", 1900+tm->tm_year);
							  
							  /*Utilizamos gotoxy para imprimir los datos correspondientes 
								en la estructura de nuestra tabla*/
							  gotoxy(22,4);
				  			  printf("3000");
				  						
				  			  gotoxy(53,4);
				  			  printf("%0.2f",retirfinal);
				  						 
							  gotoxy(37,4);
				  		      printf("%0.2f", depfinal);
				  						 
						   	  gotoxy(70,4);
							  printf("%0.2f", newsaldo);
							  gotoxy(35,10);
			  				  printf("");
	  						  getch();
					
						break;
						
						case 'd':
						
							tabla();
							
							//fecha
							//Declarado para generar la fecha compelta del sistema
							t=time(NULL);
  							tm=localtime(&t);
							strftime(fechayhora, 100, "%d/%m/%Y", tm);
							gotoxy(3,4);
  							printf ("%s\n", fechayhora);
  							gotoxy(22,4);
				  			printf("3000");
				  					
							/*Utilizamos gotoxy para imprimir los datos correspondientes 
								en la estructura de nuestra tabla*/	
				  			gotoxy(53,4);
				  			printf("%0.2f",retirfinal);
				  						 
							gotoxy(37,4);
				  		    printf("%0.2f", depfinal);
				  						 
							gotoxy(70,4);
							printf("%0.2f", newsaldo);
							gotoxy(35,10);
			  				printf("");
  							getch();
  							
						
						break;
						
						case 'e':
						
							printf("Hasta luego\n");
							
						break;	
											
						default:
						
							printf("Opcion invalida");
						
						break;	
							
					}	
					
					}while(opcion4!='e');	//Regresa al tipo de conulta que desea realizar
				
					break;
					
					case 2:	
						
						depositar(newsaldo, dep,depfinal, archivo,archivo2);//Llamado a nuestra funci�n
						
					break;
					
					case 3:
						
						//retiro
						retirar(newsaldo, retiro,retirfinal,archivo,archivo2);//Llamado a nuestra funci�n	
					break;
					
					case 4:	
						printf("Saliendo de las opciones\n");
					
					break;
						
					default:
					
					printf("Opcion invalida\n");
					
					break;
					
							
				}
			}while(opcion3!=4);	
			system("cls");	
			break;
			
			default: printf("Hasta luego");
			
			break;				
		}
	
	}while(opcion!=3); 	//Repite todo el proceso en caso de que el usuario eliga las opciones del banquero o de usuario
}


	//Desarrollo de las funciones implementadas/declaradas:
	
	/*La funcion para el retiro de efectivo del usuario que ingrese al banco, si es una cantidad menor a 50 o 
	mayor a 25000 se envia un mensaje de error, de lo contrario la operacion se realiza exitosamente*/
	float retirar (float &newsaldo, float &retiro,float &retirfinal,FILE *archivo,FILE *archivo2){ 	
	
		//Declaraci�n de variables
		float saldo;
		int num,cliente;
			struct datos *ptr_client; //Puntero que apunta a nuestra estructura "datos"
						if(!(archivo=fopen("altas.txt", "r"))){//Abrimos nuestro archivo original en modo lectura
							printf("El archivo prueba no existe");
							exit(1);
						}
						
						if(!(archivo2=fopen("altasclient2.txt", "a+"))){//Creamos otro archivo (a+ .. Abre/crea un archivo para lectura y escritura al final del contenido)
							printf("El archivo prueba no existe");
							exit(1);
							/* informa al sistema operativo que el programa no se ejecut� con �xito, o se anul� entre la 
							ejecuci�n debido a alg�n error u otro.*/
						}
						
						printf("Cual es tu numero de cliente es: ");						
						scanf("%d",&cliente);
						
						//Usamos feof para comprobar el indicador de fin de archivo en el flujo de archivo dado
						while(!feof(archivo)){
							
							//Escaneamos los datos dentro del archivo
							fscanf(archivo,"%[^\t]\t", ptr_client->name);
							fscanf(archivo,"%s\t", ptr_client->clave);
							fscanf(archivo,"%d\t", &ptr_client->cliente);
							fscanf(archivo,"%f\n", &ptr_client->saldo);
							
							newsaldo=ptr_client->saldo;
							//Si nuestro puntero que va hacia la estructura datos es igual al cliente que ingreso el usuario entonces:
							if(ptr_client->cliente == cliente){
			
								do{
									/*do
									{
										printf("\nCuanto dinero quieres depositar? \n");
										scanf("%f", &dep);
										num=isdigit(dep);
										
										if(num!=1){
											
											printf("DATO INCORRECTO (NO ES UN NUMERO)\n\n");
											
										}*/
							
										//Preguntamos la cant que quiere retirar
										printf("\nCuanto dinero quieres retirar? \n");
										scanf("%f", &retiro);
										
										//Si la cantidad que quiere retirar es menor a 50 y mayor a 25000 entonces:
										if(retiro<=50 || retiro>=25000){
							
											//Le dice al cliente que la cant es incorrecta
											printf("VE A SERVICIO CLIENTE\n\n");
														
										} else { //Si no se cumple lo anterior
												
											
											
											printf("Retiro exitoso de: %0.2f\n", retiro);
											newsaldo=newsaldo-retiro;//El nuevo saldo se guarda en newsaldo y se resta lo que retiro
											retirfinal=retirfinal+retiro;//Acumulamos la cantidad que se va retirando
											printf("\nSaldo Actual: $%.2f\n",newsaldo);	//Imprimimos al usuario el su nuevo saldo
										}		
									
									if (newsaldo<0) printf("Valor no valido\n");						
						
								}while(newsaldo<0);
								
								//El saldo de nuestra estructura toma el valor del nuevo saldo introducido
								ptr_client->saldo = newsaldo;
								fflush(stdin); 	//Limpia para limpiar el buffer del teclado
						
							}
							
							//Imprimimos los nuevos valores en nuestra estructura a traves de nuestro puntero ptr_client
							fprintf(archivo2,"%s\t", ptr_client->name);
							fprintf(archivo2,"%s\t", ptr_client->clave);
							fprintf(archivo2,"%d\t", ptr_client->cliente);
							fprintf(archivo2,"%0.2f\n", ptr_client->saldo);
						}

						//Cerramos nuestro archivos a traves de fclose
						fclose(archivo2);
						fclose(archivo);
						remove("altas.txt");//Removemos nuestro documento original
						rename("altasclient2.txt", "altas.txt");//El archivo copia lo renombramos como el archivo original
						/*Es decir remplazamos lo que hay en el archivo copia y lo pasamos a nuestro archivo principal*/
	}

	float depositar (float &newsaldo, float &dep, float &depfinal,FILE *archivo,FILE *archivo2){		//La funcion para depositar efectivo en una cuenta solamente permite depositar cantidades comprendidas desde 50 pesos hasta 25000, de lo contrario envia un mensaje de error
			
		//Declaracion de variables
		int num,cliente;
		struct datos *ptr_clien; //Puntero que apunta a nuestra estructura "datos"
		
		if(!(archivo=fopen("altas.txt", "r"))){//Abrimos nuestro archivo original en modo lectura
			printf("El archivo prueba no existe");
			exit(1);
		}
				
		if(!(archivo2=fopen("altasclient.txt", "a+"))){//Creamos otro archivo (a+ .. Abre/crea un archivo para lectura y escritura al final del contenido)
			printf("El archivo prueba no existe");
			exit(1);
			/* informa al sistema operativo que el programa no se ejecut� con �xito, o se anul� entre la 
							ejecuci�n debido a alg�n error u otro.*/
		}
						
		printf("Cual es tu numero de cliente es: ");						
		scanf("%d",&cliente);
						
						//Usamos feof para comprobar el indicador de fin de archivo en el flujo de archivo dado
						while(!feof(archivo)){
							
							
							//Escaneamos los datos dentro del archivo
							
							fscanf(archivo,"%[^\t]\t", ptr_clien->name);
							fscanf(archivo,"%s\t", ptr_clien->clave);
							fscanf(archivo,"%d\t", &ptr_clien->cliente);
							fscanf(archivo,"%f\n", &ptr_clien->saldo);
							
							newsaldo=ptr_clien->saldo;
							//Si nuestro puntero que va hacia la estructura datos es igual al cliente que ingreso el usuario entonces:
							if(ptr_clien->cliente == cliente){
			
								do{
									/*do
									{
										printf("\nCuanto dinero quieres depositar? \n");
										scanf("%f", &dep);
										num=isdigit(dep);
										
										if(num!=1){
											
											printf("DATO INCORRECTO (NO ES UN NUMERO)\n\n");
											
										}*/
										//Preguntamos la cant que quiere retirar
										printf("\nCuanto dinero quieres depositar? \n");
										scanf("%f", &dep);
										
										//Si la cantidad que quiere retirar es menor a 50 y mayor a 25000 entonces:

										if(dep<=50 || dep>=25000){
							
											printf("VE A SERVICIO CLIENTE\n\n");//Le dice al cliente que la cant es incorrecta
														
										} else {//Si no se cumple lo anterior
														
											printf("Deposito exitoso de %0.2f\n",dep);
											newsaldo=newsaldo+dep;//El nuevo saldo se guarda en newsaldo y se suma lo que deposito
											depfinal=depfinal+dep;//Acumulamos la cantidad que se va depositand
											printf("\nSaldo Actual: $%.2f\n",newsaldo);//Imprimimos al usuario el su nuevo saldo
											
										}	
										
									
									if (newsaldo<0) printf("Valor no valido\n");						
						
									
								}while(newsaldo<0);
								//El saldo de nuestra estructura toma el valor del nuevo saldo introducido
								ptr_clien->saldo = newsaldo;
								fflush(stdin);//Limpia para limpiar el buffer del teclado
								

						
							}
							//Imprimimos los nuevos valores en nuestra estructura a traves de nuestro puntero ptr_client

							fprintf(archivo2,"%s\t", ptr_clien->name);
							fprintf(archivo2,"%s\t", ptr_clien->clave);
							fprintf(archivo2,"%d\t", ptr_clien->cliente);
							fprintf(archivo2,"%0.2f\n", ptr_clien->saldo);
						}

						//Cerramos nuestro archivos a traves de fclose
						fclose(archivo);
						fclose(archivo2);
						remove("altas.txt");//Removemos nuestro documento original
						rename("altasclient.txt", "altas.txt");//El archivo copia lo renombramos como el archivo original
						/*Es decir remplazamos lo que hay en el archivo copia y lo pasamos a nuestro archivo principal*/
		
	
	}

	void key (char clave[10]){ //Funcion para validar la clave del cliente que quiere accesar

		int att=0, ch0, ch6, ch7, ch8, ch9, rev, cant; //Estas variables se utilizan para cada espacio de la cadena ingresada
		
		do{
		
		
		rev=0; //bandera en caso correcto de la clave de acceso
		printf("\nIngresa tu clave de acceso: "); //Clave para el usuario que quiere acceder
		scanf("%s", clave);
		cant=strlen(clave);
		
		
		//Asigna un valor 0 o 1 si el caracter en ese espacio es una letra
		
		for(int cont=0;cont<=5;cont++){ //Este ciclo for revisa los caracteres del estado si es que son letras pero aun no ponemos las combinaciones de 3 letras para cada estado
		
		ch0=isalpha(clave[cont]);
		
		if(ch0==0)
		{
		rev=1;
		}
		}
		
		ch6=isdigit(clave[6]);
		ch7=isdigit(clave[7]);
		ch8=isdigit(clave[8]);
		ch9=isdigit(clave[9]);
		
		if ((clave[0]==68 && clave[1]==69) || (clave[0]==80 && clave[1]==82) || (clave[0]==78 && clave[1]==86) || (clave[0]==83 && clave[1]==73)) //valida si las dos primeras letras son las combinaciones como tarjeta de debito 'DE'
		{
		
		if (clave[2]==77 || clave[2]==70) //Valida el tercer caracter en caso de que el usuario sea hombre o mujer
		{
		
		
		
		
		if ((clave[3]==83 && clave[4]==76 && clave[5]==80) || (clave[3]==68 && clave[4]==71 && clave[5]==79) || (clave[3]==81 && clave[4]==82 && clave[5]==79)) //valida las 3 letras de la ubicacion
		{
		
		rev=0;
		
		} else {
		
		rev=1;
		}
		} else {
		
		rev=1;
		}
		
		} else {
		
		rev=1;
		}
		
		//valida si el septimo caracter es un numero y si es igual a 0 no lo valida ya que debe ser un numero a partir de 1000
		if(clave[6]==48)
		{
		rev=1;
		}
		
		if(ch6==0 || ch7==0 || ch8==0 || ch9==0) //Validacion en caso de que alguno de los caracteres no sea numero o letra
		{
		rev=1;
		}
		
		}while(cant!=10 || rev==1); //Repite el proceso en caso de que la cantidad de caracteres de la clave sea mayor a 10, o si alguna de las validaciones fue incorrecta con la variable tipo bandera
		


}
	
 	void tabla (void){
 		
 			HANDLE hd = GetStdHandle(STD_OUTPUT_HANDLE);
			HANDLE hConsole;
			hConsole=GetStdHandle(STD_OUTPUT_HANDLE);
	
	 			system("cls");
		
							//FORMATO PARA CREAR LA TABLA
							// * Margen *
							//Esquinas
							gotoxy(1,1);
							printf("%c",201);
							gotoxy(80,1);
							printf("%c",187);
							gotoxy(1,9);
							printf("%c",200);
							gotoxy(80,9);
							printf("%c",188);
							int x,y;
							
							//Lineas
							 x=1,y=2;
							 for(int i=y;i<9;i++)//Linea vertical izquierda
								{
									gotoxy(x,i);
									printf("%c",186);
								}
							x=80,y=2;
							  for(int i=y;i<9;i++)//Linea vertical derecha
								{
									gotoxy(x,i);
									printf("%c",186);
								}
							x=2,y=1;
							 for(int i=x;i<80;i++)//Linea horizontal superior
								{
									gotoxy(i,y);
									printf("%c",205);
								}
						
							x=7,y=2;
							for(int i=y;i<80;i++)//Linea horizontal inferior
								{
									gotoxy(i,x);
									printf("%c",205);
								}
							x=2,y=3;
							for(int i=x;i<80;i++)//Linea horizontal para encabezados
								{
									gotoxy(i,y);
									printf("%c",205);
								}
						
							x=2,y=5;
							for(int i=x;i<80;i++)//Linea horizontal (segunda casilla)
								{
									gotoxy(i,y);
									printf("%c",205);
								}
								
							x=2,y=7;
							for(int i=x;i<80;i++)//Linea horizontal (segunda casilla)
								{
									gotoxy(i,y);
									printf("%c",205);
								}
								
							x=2,y=7;
							for(int i=x;i<80;i++)//Linea horizontal (segunda casilla)
								{
									gotoxy(i,y);
									printf("%c",205);
								}
								
							x=2,y=9;
							for(int i=x;i<80;i++)//Linea horizontal 
								{
									gotoxy(i,y);
									printf("%c",205);
								}
							
							x=16,y=2;
							 for(int i=y;i<=8;i++)//Linea vertical fecha
								{
									gotoxy(x,i);
									printf("%c",186);
								}
								
							x=32,y=2;
							 for(int i=y;i<=8;i++)//Linea vertical de saldo inicial
								{
									gotoxy(x,i);
									printf("%c",186);
								}
								
							x=48,y=2;
							 for(int i=y;i<=8;i++)//Linea vertical de depositos
								{
									gotoxy(x,i);
									printf("%c",186);
								}
								
							x=64,y=2;
							 for(int i=y;i<=8;i++)//Linea vertical de retiros
								{
									gotoxy(x,i);
									printf("%c",186);
								}
								
							//Coloca el texto "Fecha"
							SetConsoleTextAttribute(hd,12);
							gotoxy(6,2);
							printf("Fecha "); 
							
								
							//Coloca el texto "Saldo inicial"
							SetConsoleTextAttribute(hd,12);
							gotoxy(18,2);
							printf("Saldo inicial ");
							
							//Coloca el texto "Depositos"
							SetConsoleTextAttribute(hd,12);
							gotoxy(36,2);
							printf("Depositos ");
							
							//Coloca el texto "Retiros"
							SetConsoleTextAttribute(hd,12);
							gotoxy(53,2);
							printf("Retiros ");
							
							//Coloca el texto "Saldo Final"
							SetConsoleTextAttribute(hd,12);
							gotoxy(67,2);
							printf("Saldo Final ");
							
							
							
							gotoxy(3,12); 
							printf("%c",32);//Espacio en blanco
							getch(); //Lee un solo car�cter del teclado que no muestra el valor ingresado en la pantalla
							
							SetConsoleTextAttribute(hConsole,15);
							
 	}
	 
	
