//31 de marzo de 2022
//Uriel Martinez Monreal - 178646
//Laura Ivon Montelongo Martinez - 177291


/* El segundo avance son las funciones para el retiro, el deposito, y parte de la validacion de la clave de acceso del usuario,
	tambien las tablas para ingresar los datos de cada una de las consultas que el usuario realice, todo esto esta ubicado en la parte de abajo del 
	codigo excepto la parte de la tabla*/
	
#include <stdio.h>
#include <conio.h>	 //Librerias para las funciones del programa 
#include <stdlib.h>
#include <iostream>
#include <windows.h>
#include <string.h>
#include <ctype.h>

	struct datos{
		
	  char name[30],clave[10];
	  float saldo;
	  int cliente;
	  
	};

void retirar (float retiro);
void depositar (float dep);
void key (char clave[10]);	
void tabla (void);


void gotoxy(int x,int y){
HANDLE hcon;
hcon = GetStdHandle(STD_OUTPUT_HANDLE);
COORD dwPos;
dwPos.X = x;
dwPos.Y= y;
SetConsoleCursorPosition(hcon,dwPos);
}
int main(){
	
	HANDLE hd = GetStdHandle(STD_OUTPUT_HANDLE);
	HANDLE hConsole;
	hConsole=GetStdHandle(STD_OUTPUT_HANDLE);
	//dates *alta=(dates *)malloc(sizeof(dates));
	char clave[10], nombre[30], opcion4;
	int opcion, opcion2, opcion3,x,y;
	float dep, retiro;
	struct datos *ptr_alt;
	struct datos dar;
	ptr_alt=&dar;

do{
		
		SetConsoleTextAttribute(hConsole,15);
		printf("\tProyecto desarrollado por: \n\n");
		printf("Uriel Martinez Monreal \t Laura Ivon Montelongo Martinez\n\n");
		
		SetConsoleTextAttribute(hConsole,6);				
		printf("Bienvenido a Banco PrestaMax 'Hogar del dinero'\n\n");
		SetConsoleTextAttribute(hConsole,15);
		
		system("pause");
		system("cls");
				
		printf("Ingresa tu nombre: \n");
		scanf("%[^\n]", nombre);
			fflush(stdin);
			
		printf("\nA que sector quieres acceder?\n");
		printf("1.- Administracion del banco\n");			//Opciones para el tipo de servidor
		printf("2.- Cliente del banco\n");
		printf("3.- Salir \n");
		
		scanf("%d", &opcion);
			fflush(stdin);	
		
		switch(opcion){
			
			case 1:	
			
			
				
			do{
				
				printf("A que area quieres acceder?\n");
				printf("1.- Alta clientes\n");
				printf("2.- Modificacion de informacion\n"); 		//Opciones para el banquero
				printf("3.- Consulta de clientes\n");
				printf("4.- Salir\n");
				
				scanf("%d", &opcion2);
					fflush(stdin);
				
				switch(opcion2){
					
					case 1:	
						FILE *archivo;
						printf("Nombre: ");
						scanf("%s",ptr_alt->name);
						
						printf("Clave: ");
						scanf("%s",ptr_alt->clave);
						
						printf("Numero de cliente: ");
						scanf("%d",&ptr_alt->cliente);
						
						printf("Saldo: ");
						scanf("%f",&ptr_alt->saldo);
						
						if(!(archivo = fopen("altas.txt", "a+"))){
							printf("Error al intentar leer archivo");
							exit(1);
						}
						
						fprintf(archivo, "%s\t",ptr_alt->name);
						fprintf(archivo, "%s\t",ptr_alt->clave);
						fprintf(archivo, "%d\t",ptr_alt->cliente);
						fprintf(archivo, "%0.2f\n",ptr_alt->saldo);
						
						fclose(archivo);
						//alta clientes
					break;
					
					case 2:	
									
						//analisis_clinicos dato;
						FILE *archivo2;
						datos dato;
						int codigo, p;
						bool bandera=false;
						f(!(archivo=fopen("altas_clinicos.xls", "r"))){
							printf("Error al intentar crear el archivo");
							exit(1);
						}
						
						if(!(archivo2=fopen("altasnew.xls", "a+"))){
							printf("Error al intentar crear el archivo");
							exit(1);
						}
						fprintf(archivo, "%s\t",ptr_alt->name);
						fprintf(archivo, "%s\t",ptr_alt->clave);
						fprintf(archivo, "%d\t",ptr_alt->cliente);
						fprintf(archivo, "%0.2f\n",ptr_alt->saldo);
						
						codigo = validaEntero("\nQue quieres modificar: ");
						
						while(!feof(archivo)){
							fscanf(archivo,"%[^\t]\t", dato.name);
							fscanf(archivo,"%s\t", &dato.clave);
							fscanf(archivo,"%d\t", &dato.cliente);
							fscanf(archivo,"%0.2f\n", dato.saldo);
							if(dato.codigo == codigo){
								printf("%d\t", dato.codigo);
								printf("%s\t", dato.name);
								printf("%s\t", dato.clave);
								printf("%d\t", dato.cliente);
								printf("%0.2f\t", dato.saldo);
							}
						}
					
					break;
					
					case 3:
					
						//Consulta de clientes
						
					break;
					
					case 4:
						
						printf("Saliendo de las opciones\n");
					
					break;
						
					default:
					
					printf("Opcion invalida\n");
					
					break;			
				}
				
		}while(opcion2!=4);  //Regresa a elegir opciones para el banquero
			
			break;
				
			case 2:	
					
		do{
			
				key(clave);
				
				
				//Despues de que la clave sea valida se muestran las opciones para el usuario
		
								
				printf("A que area quieres acceder\n");
				printf("1.- Consulta de movimientos\n");	//Opciones cuando ingresa un usuario
				printf("2.- Deposito\n");
				printf("3.- Retiro\n");
				printf("4.- Salida\n");
				scanf("%d", &opcion3);
					fflush(stdin);	
							
				switch(opcion3){
					
					
				
					case 1:	
					
					do{
					
						//consulta de movimientos
						
						printf("\nQue tipo de consulta necesitas? ");
						printf("\na) Consulta por semana");
						printf("\nb) Consulta por mes");
						printf("\nc) Consulta del presente a�o");
						printf("\nd) Consulta de una fecha especifica\n");
						printf("\ne) Salir\n");
						scanf("%c", &opcion4);
							fflush(stdin);	
							
					switch(opcion4){
						
						case 'a':
							
							tabla();
							
						break;
						
						case 'b':
						
							//mes
						
						break;
						
						case 'c':
						
							//a�o
						
						break;
						
						case 'd':
						
							//fecha
							
						break;
						
						case 'e':
						
							printf("Hasta luego\n");
							
						break;	
											
						default:
						
							printf("Opcion invalida");
						
						break;	
							
					}	
					
				}while(opcion4!='e');	//Regresa al tipo de conulta que desea realizar
				
					break;
					
					case 2:	
						
						depositar(dep);		
						//deposito
						
					break;
					
					case 3:
					
						retirar(retiro);		
						//retiro
						
					break;
					
					case 4:
						
						printf("Saliendo de las opciones\n");
					
					break;
						
					default:
					
					printf("Opcion invalida\n");
					
					break;
					
							
				}
			}while(opcion3<=4);		
			break;
			
			default: printf("Hasta luego");
			
			break;				
		}
	
	}while(opcion!=3); 	//Repite todo el proceso en caso de que el usuario eliga las opciones del banquero o de usuario
}


	void retirar (float retiro){ 	//La funcion para el retiro de efectivo del usuario que ingrese al banco, si es una cantidad menor a 50 o mayor a 25000 se envia un mensaje de error, de lo contrario la operacion se realiza exitosamente
	
			printf("\nCuanto dinero quieres retirar? \n");
			scanf("%f", &retiro);
						
			if(retiro<=50 || retiro>=25000){
							
				printf("Error, cantidad invalida, vaya directo a atencion a clientes\n");
							
			} else {
							
				printf("Retiro exitoso\n");
			}	
	
	}


	void depositar (float dep){		//La funcion para depositar efectivo en una cuenta solamente permite depositar cantidades comprendidas desde 50 pesos hasta 25000, de lo contrario envia un mensaje de error
			
			printf("\nCuanto dinero quieres depositar? \n");
			scanf("%f", &dep);
						
			if(dep<=50 || dep>=25000){
							
				printf("Error, cantidad invalida, vaya directo a atencion a clientes\n");
							
			} else {
							
				printf("Deposito exitoso\n");
			}	
	
	}

	void key (char clave[10]){	//Funcion para validar la clave del cliente que quiere accesar 
	
	int att=0, ch0, ch6, ch7, ch8, ch9, rev, cant;	//Estas variables se utilizan para cada espacio de la cadena ingresada
		
	do{
			
				
					rev=0;	//bandera en caso correcto de la clave de acceso
				printf("\nIngresa tu clave de acceso: ");		//Clave para el usuario que quiere acceder
				scanf("%s", clave);
				cant=strlen(clave);
				
			
			//Asigna un valor 0 o 1 si el caracter en ese espacio es una letra			
			
			for(int cont=0;cont<=5;cont++){		//Este ciclo for revisa los caracteres del estado si es que son letras pero aun no ponemos las combinaciones de 3 letras para cada estado
				
				ch0=isalpha(clave[cont]);		
				
				if(ch0==0)
				{					
					rev=1;
				}
			}
			
			ch6=isdigit(clave[6]);
			ch7=isdigit(clave[7]);	
			ch8=isdigit(clave[8]);
			ch9=isdigit(clave[9]);
			
			 if ((clave[0]=='D' && clave[1]=='E') || (clave[0]=='P' && clave[1]=='R') || (clave[0]=='S' && clave[1]=='I') || (clave[0]=='N' && clave[1]=='V'))	//valida si las dos primeras letras son las combinaciones como tarjeta de debito 'DE'
			{
			
				rev=0;
				
				 if (clave[2]=='M' || clave[2]=='F')	//Valida el tercer caracter en caso de que el usuario sea hombre o mujer
				{
			
					rev=0;
					
					 if ((clave[3]=='S' && clave[4]=='L' && clave[5]=='P') || (clave[3]=='Q' && clave[4]=='R' && clave[5]=='O') || (clave[3]=='D' && clave[4]=='G' && clave[5]=='O'))	//valida las 3 letras de la ubicacion
					{
			
						rev=0;
			
					}
				}
			
			} else {
				
				rev=1;
			}			
					
			//valida si el septimo caracter es un numero y si es igual a 0 no lo valida ya que debe ser un numero a partir de 1000
			if(clave[6]==48)
			{
				rev=1;
			}														
					
			if(ch0==0 || ch6==0 || ch7==0 || ch8==0 || ch9==0)		//Validacion en caso de que alguno de los caracteres no sea numero o letra
			{
				rev=1;
			}
			
			att++;
																					
		}while(cant!=10 || rev==1 || att<3); 	//Repite el proceso en caso de que la cantidad de caracteres de la clave sea mayor a 10, o si alguna de las validaciones fue incorrecta con la variable tipo bandera

	}
	
 	void tabla (void){
 		
 			HANDLE hd = GetStdHandle(STD_OUTPUT_HANDLE);
			HANDLE hConsole;
			hConsole=GetStdHandle(STD_OUTPUT_HANDLE);
	
	 			system("cls");
		
							//FORMATO PARA CREAR LA TABLA
							// * Margen *
							//Esquinas
							gotoxy(1,1);
							printf("%c",201);
							gotoxy(80,1);
							printf("%c",187);
							gotoxy(1,9);
							printf("%c",200);
							gotoxy(80,9);
							printf("%c",188);
							int x,y;
							
							//Lineas
							 x=1,y=2;
							 for(int i=y;i<9;i++)//Linea vertical izquierda
								{
									gotoxy(x,i);
									printf("%c",186);
								}
							x=80,y=2;
							  for(int i=y;i<9;i++)//Linea vertical derecha
								{
									gotoxy(x,i);
									printf("%c",186);
								}
							x=2,y=1;
							 for(int i=x;i<80;i++)//Linea horizontal superior
								{
									gotoxy(i,y);
									printf("%c",205);
								}
						
							x=7,y=2;
							for(int i=y;i<80;i++)//Linea horizontal inferior
								{
									gotoxy(i,x);
									printf("%c",205);
								}
							x=2,y=3;
							for(int i=x;i<80;i++)//Linea horizontal para encabezados
								{
									gotoxy(i,y);
									printf("%c",205);
								}
						
							x=2,y=5;
							for(int i=x;i<80;i++)//Linea horizontal (segunda casilla)
								{
									gotoxy(i,y);
									printf("%c",205);
								}
								
							x=2,y=7;
							for(int i=x;i<80;i++)//Linea horizontal (segunda casilla)
								{
									gotoxy(i,y);
									printf("%c",205);
								}
								
							x=2,y=7;
							for(int i=x;i<80;i++)//Linea horizontal (segunda casilla)
								{
									gotoxy(i,y);
									printf("%c",205);
								}
								
							x=2,y=9;
							for(int i=x;i<80;i++)//Linea horizontal 
								{
									gotoxy(i,y);
									printf("%c",205);
								}
							
							x=16,y=2;
							 for(int i=y;i<=8;i++)//Linea vertical fecha
								{
									gotoxy(x,i);
									printf("%c",186);
								}
								
							x=32,y=2;
							 for(int i=y;i<=8;i++)//Linea vertical de saldo inicial
								{
									gotoxy(x,i);
									printf("%c",186);
								}
								
							x=48,y=2;
							 for(int i=y;i<=8;i++)//Linea vertical de depositos
								{
									gotoxy(x,i);
									printf("%c",186);
								}
								
							x=64,y=2;
							 for(int i=y;i<=8;i++)//Linea vertical de retiros
								{
									gotoxy(x,i);
									printf("%c",186);
								}
								
							//Coloca el texto "Fecha"
							SetConsoleTextAttribute(hd,12);
							gotoxy(6,2);
							printf("Fecha ");
								
							//Coloca el texto "Saldo inicial"
							SetConsoleTextAttribute(hd,12);
							gotoxy(18,2);
							printf("Saldo inicial ");
							
							//Coloca el texto "Depositos"
							SetConsoleTextAttribute(hd,12);
							gotoxy(36,2);
							printf("Depositos ");
							
							//Coloca el texto "Retiros"
							SetConsoleTextAttribute(hd,12);
							gotoxy(53,2);
							printf("Retiros ");
							
							//Coloca el texto "Saldo Final"
							SetConsoleTextAttribute(hd,12);
							gotoxy(67,2);
							printf("Saldo Final ");
							
							
							
							gotoxy(3,12); 
							printf("%c",32);//Espacio en blanco
							getch(); //Lee un solo car�cter del teclado que no muestra el valor ingresado en la pantalla
							
							SetConsoleTextAttribute(hConsole,15);
							//semana
							
 	}
	 
	 	
	
